#This code takes the reads from 2.9 millionth line till end because the reads that match to any of the red or green exons come from those line. This takes 4 and a half minutes to run. I'm uploading this as a safety measure because I was not able to check my original code after making the last change because it takes a long time.
#The answers for both the code will be same i.e the 3rd configuration.

import pandas as pd
import numpy as np
from array import array
import linecache
import sympy

def_val=0
count=dict.fromkeys([0,1,2,3,4],def_val)

bwt=''
with open("../data/chrX_last_col.txt","r") as fp_bwt:
    for line in fp_bwt:
    	line=line[:-1]
    	bwt+=line

i=1
ref=''
with open("../data/chrX.fa","r") as fp_ref:
    for line in fp_ref:
    	if i==1:
    		i+=1
    		continue
    	line=line[:-1]
    	ref+=line



for t in bwt:
	if t=='A':
		count[1]+=1
	if t=='C' or t=='A':
		count[2]+=1
	if t=='G' or t=='C' or t=='A':
		count[3]+=1
	if t=='T' or t=='G' or t=='C' or t=='A':
		count[4]+=1

	


def Occurrence(ch,index):
	if index<0:
		return 0
	count=occ[ch][index/10]
	for j in range(index-index%10+1,index+1):
		if bwt[j]==ch:
			count+=1
	return count
	

def fun(c):
	if c=='A':
		return 0
	if c=='C':
		return 1
	if c=='G':
		return 2
	if c=='T':
		return 3
	if c=='$':
		return 4
		
def BW_search(read):
	i=len(read)-1
	
	c1=read[i]
	c=fun(c1)
	sp=count[c]
	ep=count[c+1]-1
	#print 'sp,ep are',sp,ep
	
	while(sp<=ep and i>=1):
		c1=read[i-1]
		c=fun(c1)
		#print 'c is',c
		#print 'occ of char',c1,'in interval',sp,'is',Occurrence(c1,sp-1)
		sp=count[c]+Occurrence(c1,sp-1)
		#print 'sp is ',sp
		#print 'occ of char',c1,'in interval',ep,'is',Occurrence(c1,ep)
		ep=count[c]+Occurrence(c1,ep)-1
		i-=1
		#print 'sp,ep are',sp,ep
	if(ep<sp):
		return -1,-2
	else:
		return sp,ep



a=0
c=0
g=0
t=0
occ={'A':array('i'),'C':array('i'),'G':array('i'),'T':array('i')}
for i,ch in enumerate(bwt):
	if ch=='A':
		a+=1
	if ch=='C':
		c+=1
	if ch=='G':
		g+=1
	if ch=='T':
		t+=1
	if i%10==0:
		occ['T'].append(t)
		occ['A'].append(a)
		occ['C'].append(c)
		occ['G'].append(g)
	
chrX_index_map=pd.read_table("../data/chrX_map.txt",squeeze=True,header=None,dtype=np.int32)

r_ex=dict.fromkeys([1,2,3,4,5,6],def_val)
g_ex=dict.fromkeys([1,2,3,4,5,6],def_val)
r_flag=dict.fromkeys([1,2,3,4,5,6],def_val)
g_flag=dict.fromkeys([1,2,3,4,5,6],def_val)


range_r_ex={1:[149249757,149249868],2:[149256127,149256423],3:[149258412,149258580],4:[149260048,149260213],5:[149261768,149262007],6:[149264290,149264400]}
range_g_ex={1:[149288166,149288277],2:[149293258,149293554],3:[149295542,149295710],4:[149297178,149297343],5:[149298898,149299137],6:[149301420,149301530]}

def add_count(l):
	if len(l)==2:
		z=0.5
	else:
		z=1
	for x in l:
		for key,val in range_r_ex.iteritems():
			if x>=val[0] and x<=val[1]:
				#print key
				r_ex[key]+=z
		for key,val in range_g_ex.iteritems():
			if x>=val[0] and x<=val[1]:
				#print key
				g_ex[key]+=z

ab=0
for r in range(2900000,3066721):
	line = linecache.getline("../data/reads", r)
	line=line[:-1]
	line=line.replace('N','A')
	n=len(line)
	r1=line[:n/3]
	r2=line[n/3:2*n/3]
	r3=line[2*n/3:]
	sp1,ep1=BW_search(r1)
	sp2,ep2=BW_search(r2)
	sp3,ep3=BW_search(r3)
	len1=len(r1)
	len2=len(r2)
	len3=len(r3)
	dup=[]

	#print 'Reading read',line,ab

	if (sp1<0 or ep1<0) and (sp2<0 or ep2<0) and (sp3<0 or ep3<0):
		#print 'Continue'
		continue

	if sp1>=0 and ep1>=0:
		#print 'In 1'
		l1=[]
		for j in range(sp1,ep1+1):
			d=chrX_index_map[j]
			if d>149249750 and d<149301535:
				l1.append(d)
		#print l1,'this is l1'

		for x in l1:
			mismatch=0
			u=n/3
			for p in range(x+len1,x+len1+len2+len3):
				#print 'p is ',p
				#print line[u],ref[p]
				if line[u]!=ref[p]:
					mismatch+=1
				u+=1
			#print 'mismatch',mismatch
			if mismatch<=2:
				dup.append(x)
				#add_count(x)
	#print 'Hellllloooooooooooooooooo'

	if sp2>=0 and ep2>=0:
		#print 'In 2'
		l1=[]
		for j in range(sp2,ep2+1):
			d=chrX_index_map[j]
			if d>149248700 and d<149302595:
				l1.append(d)
		#print l1,'this is l1'


		for x in l1:
			mismatch=0
			v=2*n/3
			u=0

			for p in range(x-n/3,x):
				#print 'p is ',p
				#print line[u],ref[p]
				if line[u]!=ref[p]:
					mismatch+=1
				u+=1

			for p in range(x+len2,x+len2+len3):
				#print 'p is ',p
				#print line[v],ref[p]
				if line[v]!=ref[p]:
					mismatch+=1
				v+=1

			if mismatch<=2:
				x1=x-n/3
				if x1 not in dup:
					dup.append(x1)
					#add_count(x1)


	if sp3>=0 and ep3>=0:
		#print 'In 3'
		l1=[]
		for j in range(sp3,ep3+1):
			d=chrX_index_map[j]
			if d>149248700 and d<149302595:
				l1.append(d)
		#print l1,'this is l1'


		for x in l1:
			mismatch=0
			u=0

			for p in range(x-2*n/3,x):
				#print 'p is ',p
				#print line[u],ref[p]
				if line[u]!=ref[p]:
					mismatch+=1
				u+=1

			#print 'mismatch is',mismatch
			if mismatch<=2:
				x1=x-2*n/3
				if x1 not in dup:
					dup.append(x1)
					#add_count(x1)
	dup.sort()
	if dup:
		add_count(dup)


print r_ex
print g_ex



prob_of_models={1:[(1.0/3.0,2.0/3.0),(1.0/3.0,2.0/3.0),(1.0/3.0,2.0/3.0),(1.0/3.0,2.0/3.0)],2:[(0.5,0.5),(0.5,0.5),(0,1),(0,1)],3:[(33.0/133.0,100.0/133.0),(33.0/133.0,100.0/133.0),(0.5,0.5),(0.5,0.5)],4:[(33.0/133.0,100.0/133.0),(33.0/133.0,100.0/133.0),(33.0/133.0,100.0/133.0),(0.5,0.5)]}

prob_list=[]

for model,prob in prob_of_models.iteritems():
	model_prob=1
	for exon in range(2,6):
		r=r_ex[exon]
		g=g_ex[exon]
		total=r+g
		model_prob*=sympy.binomial(total,r)*(prob[exon-2][0]**r)*(prob[exon-2][1]**g)
	prob_list.append(model_prob)
	
maximum_pobability=max(prob_list)
	
for i,prob in enumerate(prob_list):
	if prob==maximum_pobability:
		model=i+1
	print 'Probability of model '+str(i+1)+' is',prob
	
print 'The model having highest probability is', model





	
